INSERT INTO Books (title, author, genre, price, stock_quantity) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 'Classic', 10.99, 50),
('1984', 'George Orwell', 'Dystopian', 8.99, 100),
('To Kill a Mockingbird', 'Harper Lee', 'Classic', 12.99, 30);

INSERT INTO Customers (name, email, city) VALUES
('John Doe', 'john.doe@example.com', 'New York'),
('Jane Smith', 'jane.smith@example.com', 'Los Angeles'),
('Alice Johnson', 'alice.johnson@example.com', 'Chicago');

INSERT INTO Orders (customer_id, order_date, status) VALUES
(1, '2024-10-01', 'Completed'),
(2, '2024-10-05', 'Pending'),
(3, '2024-10-08', 'Shipped');

INSERT INTO Order_Items (order_id, book_id, quantity, price) VALUES
(1, 1, 2, 10.99),
(1, 2, 1, 8.99),
(2, 3, 1, 12.99),
(3, 1, 1, 10.99);

INSERT INTO Invoices (order_id, invoice_date, total_amount) VALUES
(1, '2024-10-01', 30.97),
(2, '2024-10-05', 12.99),
(3, '2024-10-08', 10.99);
