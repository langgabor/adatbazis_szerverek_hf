SELECT o.order_id, c.name, o.status
	FROM Orders o
	JOIN Customers c ON o.customer_id = c.customer_id;
