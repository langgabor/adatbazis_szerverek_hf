SELECT c.name, o.order_date, b.title, oi.quantity
	FROM Customers c
	JOIN Orders o ON c.customer_id = o.customer_id
	JOIN Order_Items oi ON o.order_id = oi.order_id
	JOIN Books b ON oi.book_id = b.book_id
	ORDER BY o.order_date;
