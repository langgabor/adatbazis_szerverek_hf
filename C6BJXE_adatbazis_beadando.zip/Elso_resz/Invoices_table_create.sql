CREATE TABLE Invoices (
    invoice_id SERIAL PRIMARY KEY,
    order_id INT REFERENCES Orders(order_id),
    invoice_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_amount DECIMAL(10, 2) NOT NULL
);