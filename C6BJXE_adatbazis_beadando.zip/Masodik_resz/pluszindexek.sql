CREATE INDEX idx_orders_order_date ON Orders(order_date);
CREATE INDEX idx_order_items_order_id ON Order_Items(order_id);
CREATE INDEX idx_order_items_book_id ON Order_Items(book_id);
