SELECT 
    c.name AS customer_name,
    c.email AS customer_email,
    o.order_id,
    o.order_date,
    b.title AS book_title,
    oi.quantity,
    oi.price
FROM 
    Customers c
JOIN 
    Orders o ON c.customer_id = o.customer_id
JOIN 
    Order_Items oi ON o.order_id = oi.order_id
JOIN 
    Books b ON oi.book_id = b.book_id
WHERE 
    o.order_date = (
        SELECT MAX(order_date)
        FROM Orders
        WHERE customer_id = c.customer_id
    )
ORDER BY 
    o.order_date DESC;
