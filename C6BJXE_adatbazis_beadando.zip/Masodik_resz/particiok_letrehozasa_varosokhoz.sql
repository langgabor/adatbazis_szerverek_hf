CREATE TABLE Customers_NewYork PARTITION OF Customers FOR VALUES IN ('NewYork');
CREATE TABLE Customers_LosAngeles PARTITION OF Customers FOR VALUES IN ('LosAngeles');
CREATE TABLE Customers_Chicago PARTITION OF Customers FOR VALUES IN ('Chicago');
CREATE TABLE Customers_SanFrancisco PARTITION OF Customers FOR VALUES IN ('SanFrancisco');
