CREATE OR REPLACE FUNCTION top_selling_books()
RETURNS TABLE(title VARCHAR, total_sold INT)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT b.title, SUM(oi.quantity)::INT AS total_sold
  FROM Books b
  JOIN Order_Items oi ON b.book_id = oi.book_id
  GROUP BY b.title
  ORDER BY total_sold DESC
  LIMIT 10;
END;
$$;
