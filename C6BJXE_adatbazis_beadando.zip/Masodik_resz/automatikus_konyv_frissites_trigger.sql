CREATE TRIGGER update_stock
AFTER INSERT ON Order_Items
FOR EACH ROW
BEGIN
  UPDATE Books
  SET stock_quantity = stock_quantity - NEW.quantity
  WHERE book_id = NEW.book_id;
END;
