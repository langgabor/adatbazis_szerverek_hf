INSERT INTO Customers (customer_id, name, email, city) VALUES
(1, 'John Doe', 'john.doe@example.com', 'NewYork'),
(2, 'Jane Smith', 'jane.smith@example.com', 'LosAngeles'),
(3, 'Alice Johnson', 'alice.johnson@example.com', 'Chicago'),
(4, 'Bob Brown', 'bob.brown@example.com', 'SanFrancisco');
