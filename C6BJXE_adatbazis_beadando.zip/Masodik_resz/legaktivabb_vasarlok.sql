CREATE OR REPLACE FUNCTION most_active_customers()
RETURNS TABLE(name VARCHAR, total_orders INT)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT c.name, COUNT(o.order_id)::INT AS total_orders
  FROM Customers c
  JOIN Orders o ON c.customer_id = o.customer_id
  GROUP BY c.name
  ORDER BY total_orders DESC
  LIMIT 10;
END;
$$;
