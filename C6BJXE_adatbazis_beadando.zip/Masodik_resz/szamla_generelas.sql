CREATE OR REPLACE PROCEDURE generate_invoice(IN p_order_id INT)
LANGUAGE plpgsql
AS $$
DECLARE
  total DECIMAL(10, 2);
BEGIN
  SELECT SUM(price * quantity) INTO total FROM Order_Items WHERE order_id = p_order_id;
  INSERT INTO Invoices (order_id, invoice_date, total_amount) VALUES (p_order_id, NOW(), total);
END;
$$;
