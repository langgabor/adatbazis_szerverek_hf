DO $$
DECLARE
    i INT;
    name VARCHAR(255);
    email VARCHAR(255);
    city VARCHAR(100);
BEGIN
    -- NewYork
    FOR i IN 1..2500 LOOP
        name := substr(md5(random()::text), 1, 10);
        email := substr(md5(random()::text), 1, 5) || '@example.com';
        BEGIN
            INSERT INTO Customers (customer_id, name, email, city)
            VALUES (i, name, email, 'NewYork');
        EXCEPTION WHEN unique_violation THEN
            -- Skip duplicate entries
        END;
    END LOOP;

    -- LosAngeles
    FOR i IN 1..2500 LOOP
        name := substr(md5(random()::text), 1, 10);
        email := substr(md5(random()::text), 1, 5) || '@example.com';
        BEGIN
            INSERT INTO Customers (customer_id, name, email, city)
            VALUES (i + 2500, name, email, 'LosAngeles');
        EXCEPTION WHEN unique_violation THEN
            -- Skip duplicate entries
        END;
    END LOOP;

    -- Chicago
    FOR i IN 1..2500 LOOP
        name := substr(md5(random()::text), 1, 10);
        email := substr(md5(random()::text), 1, 5) || '@example.com';
        BEGIN
            INSERT INTO Customers (customer_id, name, email, city)
            VALUES (i + 5000, name, email, 'Chicago');
        EXCEPTION WHEN unique_violation THEN
            -- Skip duplicate entries
        END;
    END LOOP;

    -- SanFrancisco
    FOR i IN 1..2500 LOOP
        name := substr(md5(random()::text), 1, 10);
        email := substr(md5(random()::text), 1, 5) || '@example.com';
        BEGIN
            INSERT INTO Customers (customer_id, name, email, city)
            VALUES (i + 7500, name, email, 'SanFrancisco');
        EXCEPTION WHEN unique_violation THEN
            -- Skip duplicate entries
        END;
    END LOOP;
END $$;