CREATE TABLE Customers (
    customer_id INT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    PRIMARY KEY (customer_id, city),
    UNIQUE (email, city)
) PARTITION BY LIST (city);
